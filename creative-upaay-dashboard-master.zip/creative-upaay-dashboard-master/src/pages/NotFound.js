export default function NotFound() {
  return <div className="p-10 text-center text-2xl">404 - Page Not Found</div>;
}
